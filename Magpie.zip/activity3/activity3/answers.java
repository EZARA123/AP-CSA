
/**
 * Write a description of class answers here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class answers
{
    /*
     * findKeyword("She's my sister", "sister", 0);
     * 
     * Iteration    psn     before      after
     * 1             9      " "         "" 
     * 
     * findKeyword("Brother Tom is helpful, "brother", 0);
     * 
     * Iteration    psn     before      after
     * 1            0       ""          ""   
     * 
     * findKeyword("I can't catcth wild cats.", "cat", 0);
     * 
     * Iteration    psn     before      after
     * 1            8      " "         "c"
     * 2            19     " "         "s"
     * 
     * findKeyword("I know nothing about snow plows.", "no", 0);
     * 
     * Iteration    psn     before      after
     * 1            3       "k"         "w"
     * 2            7       " "         "t"
     * 3            22      "s"         "w"
     */
}
