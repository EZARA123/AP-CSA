
/**
 * Write a description of class Answers here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Answers
{
    //It goes by order by which the code is type it prioritize the order of the responses.
    //
}
